
# NOVA AI Backend
Instructions to run locally:
```
pip install -r requirements.txt
export OPENAI_API_KEY=your_openai_key
export DETA_PROJECT_KEY=your_deta_key
python app.py
```
Deploy on Deta Space:
```
deta deploy
```
