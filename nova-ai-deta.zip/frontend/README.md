
# NOVA AI Frontend
Instructions to run locally:
```
npm install
npm start
```
Update `backendUrl` in App.jsx to your Deta Space URL.
Deploy on Vercel for free.
